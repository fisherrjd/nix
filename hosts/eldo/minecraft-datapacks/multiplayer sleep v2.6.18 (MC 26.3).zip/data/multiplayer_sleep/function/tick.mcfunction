schedule function multiplayer_sleep:tick 1t
execute as @a[scores={mpSleep=1..}] run function multiplayer_sleep:trigger
# Straw beds do not fire slept_in_bed; detect sleepers when tracking is idle.
execute unless score #sleeping mpSleep.dummy matches 1.. as @a[gamemode=!spectator,predicate=multiplayer_sleep:overworld] if data entity @s sleeping_pos run scoreboard players set #sleeping mpSleep.dummy 1
execute if score #sleeping mpSleep.dummy matches 1.. run function multiplayer_sleep:check_sleeping